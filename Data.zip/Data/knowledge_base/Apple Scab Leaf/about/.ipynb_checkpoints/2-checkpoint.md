```markdown
# Apple Scab of Apples and Crabapples

### About

- **Overview**: Apple scab is the most common disease of apple and crabapple trees in Minnesota.
- **Causative Agent**: Caused by the fungus *Venturia inaequalis*.
- **Hosts**: Infects apples (*Malus spp.*), crabapples, mountain ash (*Sorbus spp.*), pear (*Pyrus communis*), and Cotoneaster (*Cotoneaster spp.*).

#### Symptoms
- **Leaves**:
  - Round, olive-green spots (up to 1/2 inch).
  - Spots are velvet-like with fringed borders.
  - Aging spots turn dark brown to black, gradually increase in size, and often merge together.
  - Leaves with extensive infections turn yellow and drop by mid-summer.

- **Fruit**:
  - Olive-green spots that develop into brown and corky textures over time.
  - Young infected fruits can be deformed and cracked.

#### Life Cycle
- The fungus overwinters on fallen diseased leaves.
- In spring, spores are released into the air, infecting new growth.
- Infection thrives in warm, rainy conditions.
- Several years of early leaf loss can weaken the tree.

#### Management Strategies
- Clean up fallen leaves in the fall to limit overwintering sites for the fungus.
- Use good cultural practices:
  - Proper planting and pruning to improve air circulation.
  - Do not overcrowd plants.
- Select disease-resistant varieties.

### Cure

- **Fungicides**: Can be used for managing apple scab, but they do not cure already infected trees.
  - **Application Timing**: Start when the first green leaf tips appear (known as "half-inch green tip").
  - **Spray Interval**: Refer to fungicide labels for guidance on application frequency.
    - Shorter interval under rainy conditions or where scab has been problematic.
    - Longer interval during dry spells or where scab was not a previous issue.

- **Fungicides for Edible Trees**:
  - Active ingredients include captan, lime-sulfur, and powdered/wettable sulfur.
  - Avoid using all-purpose sprays that contain insecticides, especially during bloom.

- **Use of Fungicides for Ornamental Trees**: 
  - Only applicable before infection is present.
  - Key active ingredients:
    - Tebuconazole
    - Myclobutanil
    - Captan
    - Chlorothalonil
    - Propiconazole
    - Mancozeb
    - Sulfur/lime sulfur
    - Neem oil
    - Copper

- **Post-Infection Care**:
  - If the tree has already been infected, refrain from applying fungicides that year.
  - Follow up with good sanitation practices in the fall and consider fungicides the following spring.
```