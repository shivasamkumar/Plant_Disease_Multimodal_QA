```markdown
### About

- **Common Name**: Apple leaf  
- **Scientific Name**: Philenoptera violaceae
- **Description**: 
  - A medium-sized tree with a single meandering trunk.
  - Features a wide-spreading sparse and rounded crown.
- **Habitat**: 
  - Usually found close to permanent or seasonal water sources.
  - Drought-resistant and sensitive to frost.
  
- **Conservation Status**: Protected in South Africa  
- **Height**: Up to 15 m  
- **Foliage**: Deciduous to semi-deciduous  
- **Family**: Fabaceae (Pod bearing)  
- **Sub Family**: Papilionoideae (Pea sub-family)

- **Traditional Uses**: 
  - Bark and roots are used in self-contained pools to deoxygenate water, resulting in fish floating to the surface.
  - Traditionally used to make dug-out canoes.
  - Roots inhaled as a remedy for the common cold.
  - Powdered roots and bark used to treat snake bites.

- **Folklore**: 
  - Cutting down an apple-leaf tree is said to bring bad luck and cause rifts in families.
  - It is illegal to cut down the tree in South Africa.

- **Notable Features**: 
  - Large leathery leaves that when crushed sound like a bite (hence the name).
  - Violet flowers appear in October and November.
  - Inhabited by spittle bugs (Ptyelus grossus) which cause the tree to appear to rain due to their sap absorption.
```