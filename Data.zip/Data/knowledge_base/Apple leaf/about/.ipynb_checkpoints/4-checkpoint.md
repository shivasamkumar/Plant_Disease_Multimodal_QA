```markdown
# Apple Leaf

### About
- **Common Name:** Apple  
- **Scientific Name:** *Malus pumila*  
- **Description:** 
  - Deciduous small to medium-sized tree
  - Height: 30 to 70 feet
  - Short, stout trunk
  - Leaves: 2 to 4 inches long, oval to ovate with fine sharp-toothed margins
  - Leaf Color: Bright green on top; paler with fine white down underneath

- **Hardiness:** Zones 3 through 10 (depending on species)  
- **Growth Rate:** Moderate  
- **Mature Shape:** Ovular spreading or horizontal upright  
- **Height Variants:**
  - Dwarf varieties: 5 to 8 feet tall
  - Semi-dwarf: 12 to 16 feet tall
  - Standard varieties: 20 to 30 feet tall
- **Width:** Depends upon variety  
- **Site Requirements:** Grows well in moist, well-drained soil  
- **Flowering Dates:** May  
- **Seed Dispersal Dates:** September  
- **Seed Bearing Age:** 4 years  
- **Seed Bearing Frequency:** Yearly  

- **Cultivation:** 
  - Grown from buds through a process called budding (a type of grafting)
  - Originated in Eurasia and brought to North America by early colonists
  - Now naturalized in North America, with thousands of cultivars

- **Uses:** 
  - Wood: Heavy, hard, and tough; used for crafts and fuel
  - Fruit: Widely used in culinary dishes and also as a food source for wildlife (e.g., white-tailed deer, black bear, raccoons, foxes)

- **Habitat of Prairie Crab Apple:**
  - Found in prairie settings, dry brush uplands, and open woods throughout Iowa  
- **Distinction Between Apple and Crab Apple:** 
  - General rule: Fruit under 2 inches is a crab apple; fruit larger than 2 inches is an apple, though many trees can hybridize.

### Pests that Can Affect Apple Trees
- Apple Maggot
- Codling Moth
- Eastern Tent Caterpillar
- Flathead Borers
- Oystershell Scale
- Walking Stick
- Yellowbellied Sapsucker
```