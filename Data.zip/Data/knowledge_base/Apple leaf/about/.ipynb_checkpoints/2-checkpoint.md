```markdown
### About

Apple leaf disease information is derived from **USDA FoodData Central**, which is a comprehensive source of food composition data. The USDA manages this data under the Agricultural Research Service's Beltsville Human Nutrition Research Center.

**Key Features:**
- **Various Data Types**:
  - Analytical data/metadata on commodity and minimally processed food samples.
  - Historical data derived from analyses, calculations, and published literature.
  - Data to analyze foods/beverages reported in What We Eat in America, NHANES.
  - Peer-reviewed journal data in collaboration with USDA.
  - Label data collected through public-private partnerships.

- **Updates**:
  - Analytical data is updated biannually (April & October).
  - Historical data final update was in 2018.
  - Foundation Foods & SR Legacy updates occur every 2 years.
  - Monthly updates for commercial food brands data.
  - The USDA Global Branded Food Products Database is also updated monthly.

- **Accessibility**:
  - FoodData Central is primarily accessible on desktop - advanced filtering features are not currently mobile-enabled.
  
- **Licensing**:
  - Data is in the public domain, published under CC0 1.0 Universal.
  - Users can use the data without permission but are encouraged to cite FoodData Central.
```
