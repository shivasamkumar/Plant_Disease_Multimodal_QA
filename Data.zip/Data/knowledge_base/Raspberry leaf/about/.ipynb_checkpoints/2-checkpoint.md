```markdown
### About

**Raspberry Leaf** (Rubus Idaeus)

- Community Score: 82 (33 reviews)
- Organic and Caffeine-free
- Origin: Bulgaria
- Elevation: 100m
- Picking & Processing: Leaves
- Aromatic Descriptions:
  - **Dry Leaf:** Acorn brown and white cut leaves with a fresh dry earthiness.
  - **Wet Leaf:** Earth and milky raw nuts aroma.
  - **Liquor:** Golden ale appearance.
  - **Empty Cup:** Extremely light dried grass aroma.

**Flavor Profile:**
- Texture: Very thin
- Taste: Light and herbaceous with a slight mintiness
- Finish: Light and fresh
- Body Sensation: Calm and warming

**Nutritional Benefits:**
- Naturally high in:
  - Magnesium
  - Potassium
  - B and C vitamins
  - Iron
- Traditionally used for:
  - Supporting pregnant women by toning uterine muscles, potentially leading to shorter labor
  - Combating diarrhea and GI tract disorders
  - Addressing respiratory conditions such as colds and flu
  - Providing a protective effect on the prostate for men

### Cure

**Traditional Uses:**
- Used to assist with pregnancy and labor.
- May help alleviate gastrointestinal and respiratory issues.

**References for Further Reading:**
- Durgo K et al. (2012). *The bioactive potential of red raspberry leaves*. Journal of Medicinal Food. [Link](http://www.ncbi.nlm.nih.gov/pubmed/22082102)
- Holst L, Haavik S, Nordeng H (2009). *Raspberry leaf--should it be recommended to pregnant women?* Complementary Therapies in Clinical Practice. [Link](http://www.ncbi.nlm.nih.gov/pubmed/19880082)
- Simpson M et al. (2001). *Raspberry leaf in pregnancy: its safety and efficacy in labor*. Journal of Midwifery and Women’s Health. [Link](http://www.ncbi.nlm.nih.gov/pubmed/11370690)
```
