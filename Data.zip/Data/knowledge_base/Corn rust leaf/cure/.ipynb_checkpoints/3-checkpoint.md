```markdown
### Cure

Both southern and common rust have been confirmed in multiple corn fields in Ohio, with common rust being more widespread. 

- **Characteristics:**
  - **Southern Rust:** Small, circular, light orangish pustules on the upper leaf surface.
  - **Common Rust:** Larger, elongated, and darker (cinnamon-brown) pustules on both leaf surfaces.

- **Growth Stages:**
  - Most early-planted fields are now between R1 (silk emergence) and late-R2 (brown silk), making them less likely to be heavily impacted by rust.
  - Late-planted fields (approximately V10 to V18) are at greater risk for yield reduction.

- **Spread and Severity:**
  - Rust spreads quickly under favorable conditions, depending on the availability of spores and the development of new pustules.
  - Southern rust can be particularly damaging if susceptible hybrids are infected early in the season during warm and wet conditions.

- **Fungicide Recommendations:**
  - Several commonly used foliar fungicides provide good to excellent control of both rust diseases.
  - **Timing is critical:** Apply fungicides as soon as the first few pustules are observed to reduce disease development and spread.
  - Prioritize the latest-planted fields, as they are at the highest risk for damage and yield loss.
```